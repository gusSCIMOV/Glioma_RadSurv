#!/bin/bash 

cd $DATA
CASES=(`ls`)
echo "Subject ID: ${CASES[$j]}"

# f=$1; m=$2

# PROG=/mnt/Data7/jxm877/ShapeFeatures3D_HPC/build/ShapeFeatures3D
# RESULTS=/home/ngb18/PROCESSED/Marwa
vol=$1 #input file
echo "Intensity Image: $vol"
mask=$2 #input file
echo "Label Image: $mask"

#check patient number
#cutoff=10
#if [[ "$j" -lt "$cutoff" ]];then #if j<10, we need the "0" in front
#	patient=RectalCA\-\0$j
#else
#	patient=RectalCA\-$j
#fi

#Check image extensions
echo "Checking image extension .nii or .nii.gz"
img_ext=$(echo "$vol" | sed 's/.*\.*\.\(.*\)/\1/')
if [ "$img_ext" == "gz" ]; then
    OUTPUT_PATH=$(echo "$vol" | sed 's/\(.*\/\).*\..*\..*/\1/')
    outim=$(echo "$vol" | sed 's/.*\/\(.*\)\..*\..*/\1/')
    echo "OUTPUT PATH: $OUTPUT_PATH"
    echo "OUTPUT IMAGE string: $outim"
else
    OUTPUT_PATH=$(echo "$vol" | sed 's/\(.*\/\).*\..*/\1/')
    outim=$(echo "$vol" | sed 's/.*\/\(.*\)\..*/\1/')
    echo "OUTPUT PATH: $OUTPUT_PATH"
    echo "OUTPUT IMAGE string: $outim"
fi

#cd $RESULTS
#mkdir $folderarray	
#extract shape from isotropic volume!
#vol=$DATA/$folderarray/vol_iso_VxSz_1\.mha
#mask=$DATA/$folderarray/mask_iso\.mha

# Merge label 3 and label 4 (for pediatric medullo)
$AP/ImageMath 3 $OUTPUT_PATH/Label_cyst_NET.nii.gz ReplaceVoxelValue $mask 3 4 3
#$AP/ImageMath 3 $OUTPUT_PATH/Label_habitat.nii.gz ReplaceVolxelValue $mask 1 4 1

# Call to Extract 3D Features	
# <$PATH/ShapeFeatures3D> <LabelImage> <IntensityImage> <OutputFeatureFile.txt>
# $PROG $mask $vol $RESULTS/$folderarray/shape_feats\.txt 
$PROG $OUTPUT_PATH/Label_cyst_NET.nii.gz $vol $OUTPUT_PATH/shape_feats\.txt
