#!/bin/bash 

# there are two .sh files:
#a) The one that submits a job to the queue(shape_feature_extraction_bashloop.sh ..aka this one) 
#b)	The one that says what is happening during the job (shape_feature_extraction.sh)

#STEPS (copy and paste these into command window)
#1) login to hpc1.case.edu (using Putty)
#
#2) set path: 
#		 cd /mnt/projects/CSE_BME_AXM788/home/jacob/Projects/UH_Rectal_Radiology/Code/Feature_Extraction/
#2) convert scripts from windows to unix:
#		 dos2unix shape_feature_extraction_bashloop.sh
#		 dos2unix shape_feature_extraction.sh
#3) call main script!
#		 ./shape_feature_extraction_bashloop.sh
#4) check status of jobs
#		 squeue -u <username>

# The other .sh file we want to execute
directory=01
mother_path=${_CONDOR_SCRATCH_DIR}

IMSTR=T1_POST_REG_BIAS_brain
MASK=All-label_transform_updated

tar -xzf ${directory}.tar.gz
tar -xzf script.tar.gz
tar -xzf ShapeFeatures.tar.gz
tar -xzf ANTS.tar.gz

SCRIPT=${mother_path}/shape_feature_extraction.sh
PROG=${mother_path}/ShapeFeatures3D_HPC/build/ShapeFeatures3D
AP=${mother_path}/build/bin

# Create script output folder for multiple jobs
SC=$(echo "$SCRIPT" | sed 's/.*\/\(.*\)\..*/\1/')
OUTPUT_LOG=$SC"_$IMSTR"

mkdir ${mother_path}/LOG
LOGDIR=${mother_path}/LOG/${OUTPUT_LOG}

if [[ -d $LOGDIR ]]; then
    rm -Rf $LOGDIR/*
    rmdir $LOGDIR
fi

mkdir $LOGDIR
echo $LOGDIR

DATA=${mother_path}/${directory}
cd $DATA
folderarray=(`ls`)

for ((j=0; j<${#folderarray[@]}; j++))
do
    # sbatch --export j=$j,folderarray=${folderarray[$j]},DATA=$DATA  --nodes=1 --ntasks-per-node=5 --time=3:00:00 $SCRIPT $DATA/${folderarray[j]}/T1.nii $DATA/${folderarray[j]}/mask.nii
    cd $LOGDIR
    export j=$j DATA=$DATA PROG=$PROG AP=$AP 
    bash $SCRIPT $DATA/${folderarray[j]}/${IMSTR}.nii.gz $DATA/${folderarray[j]}/${MASK}.nii.gz
done

cd ${mother_path}
output_name=shape_${IMSTR}_${directory}
tar -czf ${output_name}.tar.gz ${directory}/
